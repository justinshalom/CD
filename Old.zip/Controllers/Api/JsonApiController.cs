﻿using System;
using System.Text.RegularExpressions;
using System.Web.Http;
using System.Xml;
using System.Xml.Linq;
using AngleSharp.Parser.Html;
using CsQuery;
using Editor.Code;
using Editor.Code.File;
using Editor.Code.Html;

namespace Editor.Controllers
{
    /// <summary>
    /// Json Api Requests
    /// </summary>
    /// <seealso cref="Editor.Controllers.BaseApiController" />
   
    public class JsonApiController : BaseApiController
    {
      

    }
}