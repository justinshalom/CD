﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Editor.Controllers
{
    public class ModelController : BaseController
    {
        // GET: Model
        public ActionResult GenerateModel()
        {
            return View();
        }
        // GET: Model
        
    }
}