﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="DbModel.cs" company="JL">
//   
// </copyright>
// <summary>
//   DB Model
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace Editor.Models.DataAccess
{
    using System;
    using System.Data;
    using System.Data.Sql;
    using System.Data.SqlClient;

    using Editor.Code.Config;
    using Editor.Code.Sql;

    /// <summary>
    /// DB Model
    /// </summary>
    public class DbModel
    {
        /// <summary>
        /// The get all table names.
        /// </summary>
        /// <returns>
        /// The <see cref="DataSet"/>.
        /// </returns>
        /// <exception cref="Exception">Throw exception
        /// </exception>
        public static DataSet GetAllTableNames()
        {
            try
            {
                DataSet db = Sql.ExecuteDataset(DbConnection.DefaultString, CommandType.StoredProcedure, "Auto_GetTables");
                return db;
            }
            catch (Exception ex)
            {
                // Logger.Error(ex, "Error In GetAllTableNames of AffliateAdminDA");
                throw ex;
            }
        }

        /// <summary>
        /// The get table columns.
        /// </summary>
        /// <param name="tableName">
        /// The table name.
        /// </param>
        /// <returns>
        /// The <see cref="DataSet"/>.
        /// </returns>
        /// <exception cref="Exception">Throw Exception
        /// </exception>
        public static DataSet GetTableColumns(string tableName)
        {
            try
            {
                DataSet db = Sql.ExecuteDataset(DbConnection.DefaultString, CommandType.StoredProcedure, "Auto_GetTableColumn", new SqlParameter("@tableName", tableName));
                return db;

            }
            catch (Exception ex)
            {
                // Logger.Error(ex, "Error In PageCreation of GetParticularTableName");
                throw ex;
            }
        }

        /// <summary>
        /// The get all server names.
        /// </summary>
        /// <returns>
        /// The <see cref="DataTable"/>.
        /// </returns>
        internal static DataTable  GetAllServerNames()
        {
            string myServer = Environment.MachineName;
            
            DataTable servers = SqlDataSourceEnumerator.Instance.GetDataSources();
            return servers;
        }

        /// <summary>
        /// The get all databases.
        /// </summary>
        /// <param name="serverName">
        /// The server name.
        /// </param>
        /// <returns>
        /// The <see cref="DataTable"/>.
        /// </returns>
        internal static DataTable GetAllDatabases(string serverName)
        {
            using (var con = new SqlConnection("Data Source=" + serverName + "; Integrated Security=True;"))
            {
                con.Open();
                DataTable databases = con.GetSchema("Databases");
                return databases;
            } 


        }
    }
}